"""
Parirenyatwa Hospital Pharmacy Simulation (Group 2)
Course: HCS423 / ISH415 Simulation and Modelling
Method: Process-Interaction Approach using SimPy
"""

import random
import simpy

# Simulation Parameters
RANDOM_SEED = 42
NUM_PHARMACISTS = 1
AVG_INTERARRIVAL = 6.0  # 1 patient every 6 minutes
AVG_SERVICE_TIME = 4.0  # 1 patient every 4 minutes
SIM_TIME = 480.0        # 8-hour outpatient day (8 hours * 60 mins)

# Performance Metrics Trackers
waiting_times = []
service_times = []
busy_time = 0.0

def patient(env, name, pharmacy):
    """Models patient arrival, waiting, dispensing service, and departure."""
    global busy_time
    arrival_time = env.now
    
    # Request access to the pharmacist
    with pharmacy.request() as request:
        yield request
        
        # Service starts
        start_time = env.now
        wait = start_time - arrival_time
        waiting_times.append(wait)
        
        # Sample service time from exponential distribution
        serv_time = random.expovariate(1.0 / AVG_SERVICE_TIME)
        service_times.append(serv_time)
        busy_time += serv_time
        
        # Hold resource during dispensing
        yield env.timeout(serv_time)

def patient_generator(env, pharmacy):
    """Generates arriving patients according to a Poisson process."""
    patient_id = 1
    while True:
        # Sample inter-arrival time from exponential distribution
        interarrival = random.expovariate(1.0 / AVG_INTERARRIVAL)
        yield env.timeout(interarrival)
        
        # Create new patient process
        env.process(patient(env, f'Patient_{patient_id}', pharmacy))
        patient_id += 1

def run_simulation():
    """Initializes and runs the SimPy environment."""
    random.seed(RANDOM_SEED)
    env = simpy.Environment()
    pharmacy = simpy.Resource(env, capacity=NUM_PHARMACISTS)
    
    # Start patient generation
    env.process(patient_generator(env, pharmacy))
    
    # Run simulation for an 8-hour shift
    env.run(until=SIM_TIME)
    
    # Summary Output
    processed_patients = len(waiting_times)
    avg_wait = sum(waiting_times) / processed_patients if processed_patients > 0 else 0
    utilisation = (busy_time / SIM_TIME) * 100
    
    print("=" * 55)
    print("PARIRENYATWA PHARMACY DISPENSING WINDOW SIMULATION")
    print("=" * 55)
    print(f"Simulated Duration       : {SIM_TIME / 60:.1f} hours ({SIM_TIME:.0f} minutes)")
    print(f"Total Patients Processed : {processed_patients}")
    print(f"Average Waiting Time     : {avg_wait:.2f} minutes")
    print(f"Pharmacist Utilisation   : {utilisation:.2f}%")
    print("=" * 55)

if __name__ == "__main__":
    run_simulation()
